package com.example.ble_ispa;
import androidx.appcompat.app.AppCompatActivity;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.*;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattServer;
import android.bluetooth.BluetoothGattServerCallback;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.os.Bundle;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.le.AdvertiseCallback;
import android.bluetooth.le.AdvertiseData;
import android.bluetooth.le.AdvertiseSettings;
import android.bluetooth.le.BluetoothLeAdvertiser;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.bluetooth.BluetoothGatt;
import android.os.Bundle;
import android.os.Handler;
import android.os.ParcelUuid;
//import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import static android.bluetooth.BluetoothProfile.GATT;
import static android.bluetooth.BluetoothProfile.GATT_SERVER;
import static android.bluetooth.BluetoothProfile.STATE_CONNECTED;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemClickListener {
    private TextView mText;
    private ListView lst;
    private Button mAdvertiseButton;
    private Button mDiscoverButton;
    private Button mSend;
    private static final String TAG = MainActivity.class.getCanonicalName();
    private AdvertiseData mAdvData;
    private AdvertiseData mAdvScanResponse;
    private AdvertiseSettings mAdvSettings;
    private BluetoothLeAdvertiser mAdvertiser;
    private BluetoothDevice mDevice;
    private BluetoothGatt bgatt;
    private BluetoothGattService mService;
    private BluetoothManager mBluetoothManager;
    private BluetoothAdapter mBluetoothAdapter;
    private BluetoothGattCharacteristic mCharacteristic;
    private TextInputEditText mMessage;
    private TextView allmsg;
    private String msg="";
    private ArrayList<BluetoothDevice> mLeDevices=new ArrayList<>();
    ArrayAdapter<String> arrayAdapter;
    private String allmsges="";
    private static final UUID MSERVICE_UUID = UUID
            .fromString("4DF91029-B356-463E-9F48-BAB077BF3EF5");
    private static final UUID RX_UUID = UUID
            .fromString("3B66D024-2336-4F22-A980-8095F4898C42");
    ArrayList<String> deviceNames=new ArrayList<>();
    private final AdvertiseCallback mAdvCallback = new AdvertiseCallback() {
        @Override
        public void onStartFailure(int errorCode) {
            super.onStartFailure(errorCode);
            Log.e(TAG, "Not broadcasting: " + errorCode);
            int statusText;
            switch (errorCode) {
                case ADVERTISE_FAILED_ALREADY_STARTED:
                    statusText = R.string.status_advertising;
                    Log.w(TAG, "App was already advertising");
                    break;
                case ADVERTISE_FAILED_DATA_TOO_LARGE:
                    statusText = R.string.status_advDataTooLarge;
                    break;
                case ADVERTISE_FAILED_FEATURE_UNSUPPORTED:
                    statusText = R.string.status_advFeatureUnsupported;
                    break;
                case ADVERTISE_FAILED_INTERNAL_ERROR:
                    statusText = R.string.status_advInternalError;
                    break;
                case ADVERTISE_FAILED_TOO_MANY_ADVERTISERS:
                    statusText = R.string.status_advTooManyAdvertisers;
                    break;
                default:
                    statusText = R.string.status_notAdvertising;
                    Log.wtf(TAG, "Unhandled error: " + errorCode);
            }
            //mAdvStatus.setText(statusText);
        }

        @Override
        public void onStartSuccess(AdvertiseSettings settingsInEffect) {
            super.onStartSuccess(settingsInEffect);
            Log.v(TAG, "Broadcasting");
            //mAdvStatus.setText(R.string.status_advertising);
        }
    };
    //Scanning Periperals code
    private BluetoothLeScanner mBluetoothLeScanner;
    private Handler mHandler = new Handler();

    private ScanCallback mScanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            super.onScanResult(callbackType, result);
            System.out.println("Scanning Started");
            if (result == null
                    || result.getDevice() == null
                    || TextUtils.isEmpty(result.getDevice().getName())) {
                //ArrayAdapter<String> arrayAdapter=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,deviceNames);
                //lst.setAdapter(arrayAdapter);
                arrayAdapter.notifyDataSetChanged();
                System.out.println("No resuts");
                return;
            }StringBuilder builder = new StringBuilder(result.getDevice().getName());
            System.out.print("Scanning result: " + result);
            System.out.println("Scanning Device Names: " + builder);
            mDevice = result.getDevice();
            addDevice(mDevice,builder);
            //builder.append("\n").append(new String(result.getScanRecord().getServiceData(result.getScanRecord().getServiceUuids().get(0)), Charset.forName("UTF-8")));
           // BluetoothGatt gatt = mDevice.connectGatt(MainActivity.this, true, btleGattCallback);
            //mText.setText("Device Name:"+builder.toString());

            //ArrayAdapter<String> arrayAdapter=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,deviceNames);
            //lst.setAdapter(arrayAdapter);
            arrayAdapter.notifyDataSetChanged();
        }

        @Override
        public void onBatchScanResults(List<ScanResult> results) {
            super.onBatchScanResults(results);
        }

        @Override
        public void onScanFailed(int errorCode) {
            Log.e("BLE", "Discovery onScanFailed: " + errorCode);
            super.onScanFailed(errorCode);
        }
    };
    public void addDevice(BluetoothDevice device,StringBuilder builder) {
        if(device!=null) {
            if (!mLeDevices.contains(device)) {
                mLeDevices.add(device);
                deviceNames.add(builder.toString());

            }
        }
    }

    public MainActivity() {
        mCharacteristic =
                new BluetoothGattCharacteristic(RX_UUID,
                        BluetoothGattCharacteristic.PROPERTY_WRITE,
                        BluetoothGattCharacteristic.PERMISSION_WRITE);

       // mCharacteristic.addDescriptor(
               // Peripheral.getClientCharacteristicConfigurationDescriptor());

       // mCharacteristic.addDescriptor(
                //Peripheral.getCharacteristicUserDescriptionDescriptor(BATTERY_LEVEL_DESCRIPTION));

        mService = new BluetoothGattService(MSERVICE_UUID,
                BluetoothGattService.SERVICE_TYPE_PRIMARY);
        mService.addCharacteristic(mCharacteristic);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mBluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = mBluetoothManager.getAdapter();
       // mText = (TextView) findViewById(R.id.text);
        mDiscoverButton = (Button) findViewById(R.id.discover_btn);
        mAdvertiseButton = (Button) findViewById(R.id.advertise_btn);
        mSend =(Button) findViewById(R.id.button2);
        mMessage = (TextInputEditText) findViewById(R.id.text_1);
        allmsg =(TextView) findViewById(R.id.textView1);

        mDiscoverButton.setOnClickListener(this);
        mAdvertiseButton.setOnClickListener(this);
        mSend.setOnClickListener(this);
        mBluetoothLeScanner = BluetoothAdapter.getDefaultAdapter().getBluetoothLeScanner();
        lst=(ListView)findViewById(R.id.text);
        arrayAdapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,deviceNames);
        lst.setAdapter(arrayAdapter);
        lst.setOnItemClickListener(this);
        /*if( !BluetoothAdapter.getDefaultAdapter().isMultipleAdvertisementSupported() ) {
            Toast.makeText( this, "Multiple advertisement not supported", Toast.LENGTH_SHORT ).show();
            mAdvertiseButton.setEnabled( false );
            mDiscoverButton.setEnabled( false );
        }*/
    }
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        TextView v=(TextView) view;
        Toast.makeText(this,"ID"+i+v.getText(),Toast.LENGTH_SHORT).show();
        mLeDevices.get(i).connectGatt(MainActivity.this, true, btleGattCallback);
        mBluetoothLeScanner.stopScan(mScanCallback);

    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.discover_btn) {
            discover();

        } else if (v.getId() == R.id.advertise_btn) {
            advertise();
        }
        else if(v.getId() == R.id.button2)
        {
            send();
            msg=mMessage.getText().toString();
            mMessage.setText("");
        }
    }

    private void send()
    {
        List<BluetoothDevice> cDevice=mBluetoothManager.getConnectedDevices(GATT);
        List<BluetoothDevice> sDevice=mBluetoothManager.getConnectedDevices(GATT_SERVER);
        if(mDevice==null)
        {
            //System.out.println("NO devices found");
            if(cDevice==null)
            {
                System.out.println("NO devices found");
            }
            else
            {
                System.out.println("GATT COnnected device:");
                BluetoothGatt gatt = cDevice.get(0).connectGatt(this, true, btleGattCallback);
            }
            if(sDevice==null)
            {
                System.out.println("NO devices found");
            }
            else
            {
                System.out.println("GATT COnnected device:");
                BluetoothGatt gatt=sDevice.get(0).connectGatt(this,true,btleGattCallback);
            }

        }
        else {

            BluetoothGatt gatt = mDevice.connectGatt(this, true, btleGattCallback);
        }
    }
    private void advertise() {
        BluetoothLeAdvertiser advertiser = BluetoothAdapter.getDefaultAdapter().getBluetoothLeAdvertiser();
        ParcelUuid pUuid = new ParcelUuid(UUID.fromString(getString(R.string.ble_uuid)));
        mAdvSettings = new AdvertiseSettings.Builder()
                .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_BALANCED)
                .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM)
                .setConnectable(true)
                .build();
        mAdvData = new AdvertiseData.Builder()
                .setIncludeTxPowerLevel(true)
                .addServiceUuid(pUuid)
                .build();
        mAdvScanResponse = new AdvertiseData.Builder()
                .setIncludeDeviceName(true)
                .build();

       /* AdvertiseSettings settings = new AdvertiseSettings.Builder()
                .setAdvertiseMode( AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY )
                .setTxPowerLevel( AdvertiseSettings.ADVERTISE_TX_POWER_HIGH )
                .setConnectable(false)
                .build();

        ParcelUuid pUuid = new ParcelUuid( UUID.fromString( getString( R.string.ble_uuid ) ) );

        AdvertiseData data = new AdvertiseData.Builder()
                .setIncludeDeviceName( true )
                .addServiceUuid( pUuid )
                .addServiceData( pUuid, "Data".getBytes(Charset.forName("UTF-8") ) )
                .build();

        AdvertiseCallback advertisingCallback = new AdvertiseCallback() {
            @Override
            public void onStartSuccess(AdvertiseSettings settingsInEffect) {
                super.onStartSuccess(settingsInEffect);
                System.out.println("advertising");

            }

            @Override
            public void onStartFailure(int errorCode) {
                Log.e( "BLE", "Advertising onStartFailure: " + errorCode );
                super.onStartFailure(errorCode);
            }
        };*/
        advertiser.startAdvertising(mAdvSettings, mAdvData, mAdvCallback);
        // advertiser.startAdvertising( settings, data, advertisingCallback );
    }

    private void discover() {
        deviceNames.removeAll(deviceNames);

        mLeDevices.removeAll(mLeDevices);
        List<ScanFilter> filters = new ArrayList<ScanFilter>();

        ScanFilter filter = new ScanFilter.Builder()
                .setServiceUuid(new ParcelUuid(UUID.fromString(getString(R.string.ble_uuid))))
                //  .setServiceUuid(null)
                .build();
        //new ParcelUuid(UUID.fromString( getString(R.string.ble_uuid)
        filters.add(filter);

        ScanSettings settings = new ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .build();

        mBluetoothLeScanner.startScan(filters, settings, mScanCallback);

        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                mBluetoothLeScanner.stopScan(mScanCallback);
            }
        }, 10000);
        arrayAdapter.notifyDataSetChanged();
        System.out.println();
    }
//Bluetooth Gatt
private BluetoothGattCallback btleGattCallback = new BluetoothGattCallback() {
    @Override
    public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
        Log.d(TAG, "onConnectionStateChange: " + status + ", " + newState);

        if(newState == STATE_CONNECTED) {
            Log.d(TAG, "Device connected");
            boolean ans = gatt.discoverServices();
            Log.d(TAG, "Discover Services started: " + ans);
        }
    }

    @Override
    public void onServicesDiscovered(BluetoothGatt gatt, int status) {
        //Log.d(TAG, "Number of Services: " + gatt.getServices().size());
       /* System.out.println("Interested Service"+gatt.getService(MSERVICE_UUID));
        BluetoothGattCharacteristic characteristic =
                gatt.getService(MSERVICE_UUID)
                        .getCharacteristic(RX_UUID);
        System.out.println("characteristics "+characteristic);
        System.out.println("msg: "+msg);
        //if(msg.equals(""))
       // {
         //   System.out.println("msg is null");
        //}*/
    BluetoothGattService ser=gatt.getService(MSERVICE_UUID);
   List<BluetoothGattCharacteristic> characteristics= ser.getCharacteristics();
   System.out.println(characteristics);
   BluetoothGattCharacteristic characteristic=characteristics.get(0);
        if(!msg.equals("")&&msg!="") {
           // String val1=characteristic.getValue().toString();
           // System.out.println("Before writing val: "+val1);
            byte[] val=msg.getBytes();
            characteristic.setValue(val);
            byte[] val1=characteristic.getValue();
            String val2=new String(val1);
           // System.out.println("Before setting val: "+val1);
            gatt.writeCharacteristic(characteristic);
            msg="";
            //val1=characteristic.getValue().toString();
            System.out.println("Message sent: "+val1+" :"+val2);
            allmsges=allmsges+"Message sent:"+val2+"\n";
            allmsg.setText(allmsges);
            msg="";
        }
    }


};

    ///Bluetooth GATT Server
    private BluetoothGattServer mGattServer;
    private final BluetoothGattServerCallback mGattServerCallback = new BluetoothGattServerCallback() {
        @Override
        public void onConnectionStateChange(BluetoothDevice device, final int status, int newState) {
            super.onConnectionStateChange(device, status, newState);
            if (status == BluetoothGatt.GATT_SUCCESS) {
                if (newState == STATE_CONNECTED) {
                    // mBluetoothDevices.add(device);
                    //updateConnectedDevicesStatus();
                    mGattServer.getServices();
                    Log.v(TAG, "Connected to device: " + device.getAddress());
                } else if (newState == BluetoothGatt.STATE_DISCONNECTED) {
                    // mBluetoothDevices.remove(device);
                    //updateConnectedDevicesStatus();
                    Log.v(TAG, "Disconnected from device");
                }
            } else {
                // mBluetoothDevices.remove(device);
                //updateConnectedDevicesStatus();
                // There are too many gatt errors (some of them not even in the documentation) so we just
                // show the error to the user.
                //  final String errorMessage = getString(R.string.status_errorWhenConnecting) + ": " + status;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, "Error", Toast.LENGTH_LONG).show();
                    }
                });
                Log.e(TAG, "Error when connecting: " + status);
            }
        }

        @Override
        public void onCharacteristicWriteRequest(BluetoothDevice device, int requestId, BluetoothGattCharacteristic characteristic, boolean preparedWrite, boolean responseNeeded, int offset, byte[] value) {
            super.onCharacteristicWriteRequest(device, requestId, characteristic, preparedWrite, responseNeeded, offset, value);
            //int status=mserviceFragment.writeCharacteristic(characteristic,offset,value);
            //bgatt.writeCharacteristic(characteristic);
            characteristic.setValue(value);
String val1=new String(value);
            //System.out.print("Status"+status);
            System.out.println("Value Recieved is "+val1);
            allmsges=allmsges+"Message Received:"+val1+"\n";
            allmsg.setText(allmsges);
        }
    };
    @Override
    protected void onStart() {
        super.onStart();
        resetStatusViews();
        // If the user disabled Bluetooth when the app was in the background,
        // openGattServer() will return null.
        mGattServer = mBluetoothManager.openGattServer(this, mGattServerCallback);
        if (mGattServer == null) {
           // ensureBleFeaturesAvailable();
            return;
        }
        // Add a service for a total of three services (Generic Attribute and Generic Access
        // are present by default).
        mGattServer.addService(mService);

        if (mBluetoothAdapter.isMultipleAdvertisementSupported()) {
            mAdvertiser = mBluetoothAdapter.getBluetoothLeAdvertiser();
            mAdvertiser.startAdvertising(mAdvSettings, mAdvData, mAdvScanResponse, mAdvCallback);
        } else {
           // mAdvStatus.setText(R.string.status_noLeAdv);
        }
    }
    private void resetStatusViews() {
       // mAdvStatus.setText(R.string.status_notAdvertising);
        updateConnectedDevicesStatus();
    }
    private void updateConnectedDevicesStatus() {
        final String message = getString(R.string.status_devicesConnected) + " "
                + mBluetoothManager.getConnectedDevices(BluetoothGattServer.GATT).size();
        System.out.println(message);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
               // mConnectionStatus.setText(message);
            }
        });

    }
  /*  BluetoothGattCallback gattCallback =
            new BluetoothGattCallback() {};
    public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState)
    {
        if (newState == 0){
            gatt.discoverServices();
        }
    }
    public void onServicesDiscovered(BluetoothGatt gatt, int status){
        BluetoothGattCharacteristic characteristic =
            gatt.getService(MSERVICE_UUID)
                    .getCharacteristic(RX_UUID);
    //gatt.setCharacteristicNotification(characteristic,enabled);
        }
    public void onCharacteristicWriteRequest(BluetoothDevice device, int requestId,
                                             BluetoothGattCharacteristic characteristic, boolean preparedWrite, boolean responseNeeded,
                                             int offset, byte[] value) {
        super.onCharacteristicWriteRequest(device, requestId, characteristic, preparedWrite,
                responseNeeded, offset, value);
        Log.v(TAG, "Characteristic Write request: " + Arrays.toString(value));
        int status = mBluetoothManager.writeCharacteristic(characteristic, offset, value);
        if (responseNeeded) {
            mGattServer.sendResponse(device, requestId, status,
                    /* No need to respond with an offset 0,
                    /* No need to respond with a value  null);
        }
    }
*/

}
